function dy=P266_10_2(t,y)
dy=zeros(1,1);
dy(1)=-1000*(y(1)-sin(t))+cos(t);

