clc;
clear;
syms x y
ezplot(exp(y)+cos(x)/x+y);