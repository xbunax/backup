clc;
clear;
V=[1 3];
V1=[1 2 3];
A=diag(V);
A1=diag(V1,1);
A2=diag(V1,-1);

